.right-column 채팅 상위 요소 중 하나. popout 창에서는 없음

.chat-room : .right-column 의 하위요소. vod 페이지에서는 없음.

결국 적절한 element 가져오려면 일단 주소 가지고 경우를 판별해야 함.

그러면 실행 순서를 유형 별로 나누는게 아니라 의존성대로, 가져오는 요소와 관련되게 나눠야 함.